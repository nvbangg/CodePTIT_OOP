
import java.io.*;
import java.util.*;
public class Bai10 {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MONHOC.in"));
        ArrayList<MonHoc> ds = new ArrayList<>();
        while (sc.hasNextLine()) {
            String ma = sc.nextLine();
            if (!sc.hasNextLine()) break;
            String ten = sc.nextLine();
            if (!sc.hasNextLine()) break;
            String hinhThuc = sc.nextLine();
            boolean trung = false;
            for (MonHoc mh : ds) {
                if (mh.getMa().equals(ma)) {
                    trung = true;
                    break;
                }
            }
            if (!trung) {
                ds.add(new MonHoc(ma, ten, hinhThuc));
            }
        }
        Collections.sort(ds, new Comparator<MonHoc>() {
            public int compare(MonHoc a, MonHoc b) {
                return a.getMa().compareTo(b.getMa());
            }
        });
        for (MonHoc mh : ds) {
            System.out.println(mh.getMa() + " " + mh.getTen() + " " + mh.getHinhThuc());
        }
        sc.close();
    }
}