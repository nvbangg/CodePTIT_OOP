import java.util.*;
import java.io.*;

public class Bai12 {
    public static void main(String[] args) throws Exception {
        Manager manager = new Manager();
        manager.readInstitutions("INSTITUTION.in");
        manager.readRegister("REGISTER.in");
        List<Team> result = manager.process();
        for (Team t : result) {
            System.out.println(t);
        }
    }
}