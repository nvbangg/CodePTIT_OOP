import java.io.*;
import java.util.*;

public class Manager {
    private Map<String, Institution> map = new HashMap<>();
    private List<Team> teams = new ArrayList<>();

    public void readInstitutions(String filename) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(filename));
        int t = Integer.parseInt(sc.nextLine().trim());
        for (int i = 0; i < t; i++) {
            String line = sc.nextLine();
            int idx = line.indexOf(" ");
            String code = line.substring(0, idx).trim();
            String name = line.substring(idx + 1).trim();
            map.put(code, new Institution(code, name));
        }
        sc.close();
    }

    public void readRegister(String filename) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(filename));
        int t = Integer.parseInt(sc.nextLine().trim());
        for (int i = 0; i < t; i++) {
            String[] first = sc.nextLine().trim().split("\\s+");
            String code = first[0];
            int n = Integer.parseInt(first[1]);
            Institution inst = map.get(code);
            for (int j = 0; j < n; j++) {
                String teamName = sc.nextLine().trim();
                teams.add(new Team(teamName, inst));
            }
        }
        sc.close();
    }

    public List<Team> process() {
        Collections.sort(teams);
        for (int i = 0; i < teams.size(); i++) {
            String id = String.format("team%02d", i + 1);
            teams.get(i).setId(id);
        }
        return teams;
    }
}
