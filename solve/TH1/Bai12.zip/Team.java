public class Team implements Comparable<Team> {
    private String id;
    private String teamName;
    private Institution institution;

    public Team(String teamName, Institution institution) {
        this.teamName = teamName;
        this.institution = institution;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeamName() {
        return teamName;
    }

    public Institution getInstitution() {
        return institution;
    }

    @Override
    public int compareTo(Team other) {
        int cmp = this.institution.getName().compareTo(other.institution.getName());
        if (cmp == 0) return this.teamName.compareTo(other.teamName);
        return cmp;
    }

    @Override
    public String toString() {
        return id + " " + teamName + " " + institution.getName();
    }
}
