import java.util.*;

public class Bai6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), m = sc.nextInt();
        int[] errors = new int[m];
        for (int i = 0; i < m; i++) {
            errors[i] = sc.nextInt();
        }
        ErrorReport report = new ErrorReport(n, errors);
        System.out.println("Errors: " + report.getErrors());
        System.out.println("Correct: " + report.getCorrect());
    }
}