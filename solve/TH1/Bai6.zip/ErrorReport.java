import java.util.*;

public class ErrorReport {
    private int n;
    private List<Integer> errors;
    private List<Integer> corrects;

    public ErrorReport(int n, int[] arr) {
        this.n = n;
        errors = new ArrayList<>();
        for (int x : arr) errors.add(x);
        corrects = new ArrayList<>();
        int idx = 0;
        for (int i = 1; i <= n; i++) {
            if (idx < arr.length && arr[idx] == i) {
                idx++;
            } else {
                corrects.add(i);
            }
        }
    }

    private String compress(List<Integer> list) {
        List<String> parts = new ArrayList<>();
        int i = 0;
        while (i < list.size()) {
            int j = i;
            while (j + 1 < list.size() && list.get(j + 1) == list.get(j) + 1) j++;
            if (i == j) parts.add(String.valueOf(list.get(i)));
            else parts.add(list.get(i) + "-" + list.get(j));
            i = j + 1;
        }
        if (parts.size() == 1) return parts.get(0);
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < parts.size(); k++) {
            if (k == parts.size() - 1) sb.append("and ").append(parts.get(k));
            else if (k == parts.size() - 2) sb.append(parts.get(k)).append(" ");
            else sb.append(parts.get(k)).append(", ");
        }
        return sb.toString();
    }

    public String getErrors() {
        return compress(errors);
    }

    public String getCorrect() {
        return compress(corrects);
    }
}
