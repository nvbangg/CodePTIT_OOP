import java.io.*;
import java.util.*;


public class Bai9 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(new File("LUYENTAP.in"));
        int n = Integer.parseInt(sc.nextLine().trim());
        List<SinhVien> list = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String name = sc.nextLine();
            String[] parts = sc.nextLine().trim().split("\\s+");
            int correct = Integer.parseInt(parts[0]);
            int submit = Integer.parseInt(parts[1]);
            list.add(new SinhVien(name, correct, submit));
        }


        Collections.sort(list);


        for (SinhVien sv : list) {
            System.out.println(sv);
        }
    }
}
