public class SinhVien implements Comparable<SinhVien> {
    private String name;
    private int correct;
    private int submit;


    public SinhVien(String name, int correct, int submit) {
        this.name = name.trim();
        this.correct = correct;
        this.submit = submit;
    }


    public String getName() {
        return name;
    }


    public int getCorrect() {
        return correct;
    }


    public int getSubmit() {
        return submit;
    }


    @Override
    public int compareTo(SinhVien other) {
        if (this.correct != other.correct) {
            return Integer.compare(other.correct, this.correct);
        }
        if (this.submit != other.submit) {
            return Integer.compare(this.submit, other.submit);
        }
        return this.name.compareTo(other.name);
    }


    @Override
    public String toString() {
        return name + " " + correct + " " + submit;
    }
}





