import java.io.*;
import java.util.*;

public class Bai1 {
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(new File("MATRIX.in"));
        int t = in.nextInt();
        while (t-- > 0) {
            int n = in.nextInt(), m = in.nextInt(), k = in.nextInt() - 1;
            int[] vals = new int[n * m];
            for (int i = 0; i < n * m; i++) vals[i] = in.nextInt();
            Matrix mt = new Matrix(n, m, vals);
            mt.sortColumn(k);
            mt.print();
        }
    }
}
