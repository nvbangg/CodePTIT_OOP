import java.util.*;

public class Matrix {
    private int[][] a;
    private int n, m;

    public Matrix(int n, int m, int[] vals) {
        this.n = n;
        this.m = m;
        a = new int[n][m];
        int idx = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                a[i][j] = vals[idx++];
    }

    public void sortColumn(int col) {
        Integer[] tmp = new Integer[n];
        for (int i = 0; i < n; i++) tmp[i] = a[i][col];
        Arrays.sort(tmp);
        for (int i = 0; i < n; i++) a[i][col] = tmp[i];
    }

    public void print() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) System.out.print(a[i][j] + " ");
            System.out.println();
        }
    }
}
