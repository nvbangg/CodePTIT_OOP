import java.util.*;
import java.io.*;

public class Bai10 {
    public static void main(String[] args) throws Exception {
        Scanner sc1 = new Scanner(new File("DANHSACH.in"));
        ArrayList<SinhVien> list = new ArrayList<>();
        while (sc1.hasNextLine()) {
            String ma = sc1.nextLine().trim();
            if (ma.equals("")) continue;
            String ten = sc1.nextLine().trim();
            String lop = sc1.nextLine().trim();
            String email = sc1.nextLine().trim();
            String sdt = sc1.nextLine().trim();
            list.add(new SinhVien(ma, ten, lop, email, sdt));
        }

        HashMap<String, SinhVien> map = new HashMap<>();
        for (SinhVien x : list) map.put(x.getMa(), x);

        Scanner sc2 = new Scanner(new File("HUONGDAN.in"));
        int t = Integer.parseInt(sc2.nextLine());
        ArrayList<DoAn> res = new ArrayList<>();
        for (int i = 0; i < t; i++) {
            String line = sc2.nextLine();
            int idx = line.lastIndexOf(' ');
            String tenGV = line.substring(0, idx);
            int n = Integer.parseInt(line.substring(idx + 1));
            for (int j = 0; j < n; j++) {
                String s = sc2.nextLine();
                String[] parts = s.split("\\s+", 2);
                String maSV = parts[0];
                String tenDA = parts[1];
                SinhVien sv = map.get(maSV);
                res.add(new DoAn(maSV, sv.getTen(), tenGV, tenDA, sv.getSdt()));
            }
        }

        Collections.sort(res);
        for (DoAn x : res) System.out.println(x);
    }
}
