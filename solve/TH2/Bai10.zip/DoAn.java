public class DoAn implements Comparable<DoAn> {
    private String ma, tenSV, tenGV, tenDA, sdt;
    public DoAn(String ma, String tenSV, String tenGV, String tenDA, String sdt) {
        this.ma = ma;
        this.tenSV = tenSV;
        this.tenGV = tenGV;
        this.tenDA = tenDA;
        this.sdt = sdt;
    }
    @Override
    public int compareTo(DoAn o) {
        return this.ma.compareTo(o.ma);
    }
    @Override
    public String toString() {
        return ma + " " + tenSV + " " + tenGV + " " + tenDA + " " + sdt;
    }
}
