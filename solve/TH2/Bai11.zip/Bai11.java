import java.util.*;
import java.io.*;

public class Bai11 {
    public static void main(String[] args) throws Exception {
        Scanner mon = new Scanner(new File("MONHOC.in"));
        int m = Integer.parseInt(mon.nextLine());
        for (int i = 0; i < m; i++)
            mon.nextLine();

        Scanner gv = new Scanner(new File("GIANGVIEN.in"));
        int n = Integer.parseInt(gv.nextLine());
        ArrayList<GiangVien> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String ma = gv.next();
            String ten = gv.nextLine().trim();
            list.add(new GiangVien(ma, ten));
        }
        HashMap<String, GiangVien> map = new HashMap<>();
        for (GiangVien x : list)
            map.put(x.getMa(), x);

        Scanner gc = new Scanner(new File("GIOCHUAN.in"));
        int k = Integer.parseInt(gc.nextLine());
        for (int i = 0; i < k; i++) {
            String[] parts = gc.nextLine().split("\\s+");
            map.get(parts[0]).addGio(Double.parseDouble(parts[2]));
        }

        for (GiangVien x : list)
            System.out.println(x);
    }
}
