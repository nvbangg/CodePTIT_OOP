public class GiangVien {
    private String ma, ten;
    private double gio;

    public GiangVien(String ma, String ten) {
        this.ma = ma;
        this.ten = ten;
        this.gio = 0;
    }

    public String getMa() {
        return ma;
    }

    public String getTen() {
        return ten;
    }

    public void addGio(double g) {
        this.gio += g;
    }

    @Override
    public String toString() {
        return ten + " " + String.format("%.2f", gio);
    }
}
