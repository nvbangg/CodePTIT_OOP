import java.util.*;
import java.io.*;

public class Bai2 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), m = sc.nextInt();
        sc.nextLine();
        ArrayList<TheLoai> tl = new ArrayList<>();
        for (int i = 1; i <= n; i++) tl.add(new TheLoai(i, sc.nextLine()));
        HashMap<String, String> map = new HashMap<>();
        for (TheLoai x : tl) map.put(x.getMa(), x.getTen());
        ArrayList<Phim> list = new ArrayList<>();
        for (int i = 1; i <= m; i++) {
            String maTL = sc.nextLine();
            String ngay = sc.nextLine();
            String ten = sc.nextLine();
            int tap = Integer.parseInt(sc.nextLine());
            list.add(new Phim(i, map.get(maTL), ngay, ten, tap));
        }
        Collections.sort(list);
        for (Phim x : list) System.out.println(x);
    }
}
