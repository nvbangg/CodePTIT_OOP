import java.text.*;
import java.util.*;

public class Phim implements Comparable<Phim> {
    private String ma, ten, theloai;
    private Date ngay;
    private int sotap;
    public Phim(int id, String theloai, String ngay, String ten, int sotap) throws Exception {
        this.ma = String.format("P%03d", id);
        this.theloai = theloai;
        this.ten = ten;
        this.sotap = sotap;
        this.ngay = new SimpleDateFormat("dd/MM/yyyy").parse(ngay);
    }
    public int compareTo(Phim o) {
        if (!ngay.equals(o.ngay)) return ngay.compareTo(o.ngay);
        if (!ten.equals(o.ten)) return ten.compareTo(o.ten);
        return o.sotap - sotap;
    }
    @Override
    public String toString() {
        return ma + " " + theloai + " " +
                new SimpleDateFormat("dd/MM/yyyy").format(ngay) + " " +
                ten + " " + sotap;
    }
}
