public class TheLoai {
    private String ma, ten;
    public TheLoai(int id, String ten) {
        this.ma = String.format("TL%03d", id);
        this.ten = ten;
    }
    public String getMa() { return ma; }
    public String getTen() { return ten; }
}
