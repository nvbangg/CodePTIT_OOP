public class Polygon {
    private Point[] p;
    public Polygon(Point[] p) {
        this.p = p;
    }
    public String getArea() {
        double s = 0;
        int n = p.length;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            s += p[i].getX() * p[j].getY() - p[j].getX() * p[i].getY();
        }
        return String.format("%.3f", Math.abs(s) / 2.0);
    }
}
