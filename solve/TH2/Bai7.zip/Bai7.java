import java.util.*;
import java.io.*;

public class Bai7 {
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(new File("MUAHANG.in"));
        int n = Integer.parseInt(in.nextLine());
        Map<String, SanPham> map = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String ma = in.nextLine().trim();
            String ten = in.nextLine().trim();
            int gia = Integer.parseInt(in.nextLine().trim());
            int bh = Integer.parseInt(in.nextLine().trim());
            map.put(ma, new SanPham(ma, ten, gia, bh));
        }
        int m = Integer.parseInt(in.nextLine());
        List<KhachHang> list = new ArrayList<>();
        for (int i = 1; i <= m; i++) {
            String ten = in.nextLine().trim();
            String dc = in.nextLine().trim();
            String maSP = in.nextLine().trim();
            int sl = Integer.parseInt(in.nextLine().trim());
            String ngay = in.nextLine().trim();
            list.add(new KhachHang(i, ten, dc, maSP, sl, ngay, map));
        }
        Collections.sort(list);
        for (KhachHang x : list) System.out.println(x);
        in.close();
    }
}
