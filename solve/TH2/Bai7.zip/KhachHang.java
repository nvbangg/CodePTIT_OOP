import java.text.*;
import java.util.*;

public class KhachHang implements Comparable<KhachHang> {
    private String maKH, ten, dc, maSP, ngayMua;
    private int sl;
    private SanPham sp;
    private Date hetHan;
    public KhachHang(int stt, String ten, String dc, String maSP, int sl, String ngayMua, Map<String, SanPham> map) throws Exception {
        this.maKH = String.format("KH%02d", stt);
        this.ten = ten; this.dc = dc; this.maSP = maSP; this.sl = sl; this.ngayMua = ngayMua;
        this.sp = map.get(maSP);
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        c.setTime(df.parse(ngayMua));
        c.add(Calendar.MONTH, sp.getBh());
        this.hetHan = c.getTime();
    }
    public String getMaKH() { return maKH; }
    public Date getHetHan() { return hetHan; }
    public long getTong() { return (long) sp.getGia() * sl; }
    @Override
    public int compareTo(KhachHang o) {
        int cmp = this.hetHan.compareTo(o.hetHan);
        if (cmp == 0) return this.maKH.compareTo(o.maKH);
        return cmp;
    }
    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        return maKH + " " + ten + " " + dc + " " + maSP + " " + getTong() + " " + df.format(hetHan);
    }
}
