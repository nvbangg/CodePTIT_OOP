import java.util.*;
import java.io.*;

public class Bai8 {
    public static void main(String[] args) throws Exception {
        Scanner sc1 = new Scanner(new File("SINHVIEN.in"));
        int n = Integer.parseInt(sc1.nextLine());
        ArrayList<SinhVien> a = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String ma = sc1.nextLine();
            String ten = sc1.nextLine();
            String lop = sc1.nextLine();
            String email = sc1.nextLine();
            String sdt = sc1.nextLine();
            String gt = sc1.nextLine();
            a.add(new SinhVien(ma, ten, lop, email, sdt, gt));
        }

        Scanner sc2 = new Scanner(new File("DANGKY.in"));
        HashMap<String, String> map = new HashMap<>();
        while (sc2.hasNextLine()) {
            String[] parts = sc2.nextLine().trim().split("\\s+");
            if (parts.length == 2) map.put(parts[0], parts[1]);
        }
        for (SinhVien x : a) {
            if (map.containsKey(x.getMa())) x.setSize(map.get(x.getMa()));
        }

        Scanner sc3 = new Scanner(new File("TRUYVAN.in"));
        int q = Integer.parseInt(sc3.nextLine());
        while (q-- > 0) {
            String[] parts = sc3.nextLine().trim().split("\\s+");
            String gt = parts[0];
            String size = parts[1];
            System.out.println("DANH SACH SINH VIEN " + gt.toUpperCase() + " DANG KY SIZE " + size);
            ArrayList<SinhVien> res = new ArrayList<>();
            for (SinhVien x : a) {
                if (x.getGt().equalsIgnoreCase(gt) && size.equals(x.getSize()))
                    res.add(x);
            }
            Collections.sort(res);
            for (SinhVien x : res) System.out.println(x);
        }
    }
}
