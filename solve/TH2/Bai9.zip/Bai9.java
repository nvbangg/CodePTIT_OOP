import java.util.*;

public class Bai9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        ArrayList<CongNhan> a = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String ma = in.nextLine();
            String ten = in.nextLine();
            String vao = in.nextLine();
            String ra = in.nextLine();
            a.add(new CongNhan(ma, ten, vao, ra));
        }
        Collections.sort(a);
        for (CongNhan x : a) System.out.println(x);
    }
}
