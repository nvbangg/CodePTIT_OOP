public class CongNhan implements Comparable<CongNhan> {
    private String ma, ten;
    private int gio, phut;

    public CongNhan(String ma, String ten, String vao, String ra) {
        this.ma = ma;
        this.ten = ten;
        String[] a = vao.split(":");
        String[] b = ra.split(":");
        int start = Integer.parseInt(a[0]) * 60 + Integer.parseInt(a[1]);
        int end = Integer.parseInt(b[0]) * 60 + Integer.parseInt(b[1]);
        int total = end - start - 60;
        this.gio = total / 60;
        this.phut = total % 60;
    }

    public String getMa() {
        return ma;
    }

    public int getTong() {
        return gio * 60 + phut;
    }

    @Override
    public int compareTo(CongNhan o) {
        if (this.getTong() == o.getTong()) return this.ma.compareTo(o.ma);
        return o.getTong() - this.getTong();
    }

    @Override
    public String toString() {
        String s = gio + " gio " + phut + " phut " + (gio * 60 + phut >= 480 ? "DU" : "THIEU");
        return ma + " " + ten + " " + s;
    }
}
